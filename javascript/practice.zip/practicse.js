// console.log("hellow")
// console.log("bye")
// document.write("good")
// document.writeln("abd")
// alert("welcome to the web page")
// confirm("welcome")
// let nu=confirm("im am present")
// if(nu)
// {
//     console.log("yes")
// }
// else
// {
//     console.log("not present")
// }
// let nu1=Boolean(prompt("enter the no1"))
// let nu2=Boolean(prompt("enter the no2"))
// let num3=nu1>nu2
// console.log(num3)
// console.log(typeof nu1)
// var nu=prompt("enter the val")
// if(nu>8)
// {
// console.log("im am preseatn ")
// }
// else
// {
//     console.log("not pre")
// }
// console.log(window.nu)



// let no=1453424.54
// console.log(no.toPrecision(2))
// console.log(no.toPrecision())
// console.log(typeof no)
// let no=323
// console.log(no)
// no=String(no)
// console.log(no)
// console.log(typeof no) 
// let sal=3000
// let tax=34
// let deud=(sal*18)/100
// console.log("ur sal is"+(sal+1000)+"and the dedu id"+deud+"final sal wilbe")
// console.log(typeof  n)
// console.log(`ur sal is ${sal+1000}
// and the dedu id ${deud}
// final sal wilbe`)
// let str="Rajesh is a good boy "
// console.log(str.length)
// console.log(str[0])
// console.log(str[20])
// console.log(str.toUpperCase())
// console.log(str.toLowerCase())
// console.log(str.length-1)
// console.log(str.charAt[3])
// console.log(str.charCodeAt[1]);
// console.log(String.fromCharCode(90))
// console.log(str.indexOf("a"))
// console.log(str.indexOf("a",10))
// console.log(str.indexOf("z"))
// let email="mrs@234gmail.com"
// console.log(email.startsWith("mrs"))
// console.log(email.startsWith(".com"))
// console.log(email.endsWith(".com"))
// console.log(email.includes("@"))
// console.log(email.includes("g"))
// let name =" raj kumar "
// console.log(name.length)
// console.log(name.trim().length)
// console.log(name.trimStart().length)
// console.log(name.trimEnd().length)

let str2="Rajesh is a good boy"
console.log(str2.length)
console.log(str2.slice(0,str2.length-1))
console.log(str2.indexOf("g"))
console.log(str2.slice(12,16))
console.log(str2.slice(-5,-1))
console.log(str2.slice(-1,-5))
console.log(str2.slice(-10,17))

console.log(str2.substring(-5,5))
console.log(str2.substring(1,1))
console.log(str2.substring(0,1))
console.log(str2.substring(5,3))
console.log(str2.substr(2,4))
let ste="good morning rajesh good morning rakesh"
console.log(ste.replace("morning","evening"))
console.log(ste.replaceAll("morning","evening"))
console.log(ste.replace('g','b'))
console.log(ste.replaceAll('g','b'))
let ss="KayaKa nae ista"
console.log(ss.replace('K','N'))


